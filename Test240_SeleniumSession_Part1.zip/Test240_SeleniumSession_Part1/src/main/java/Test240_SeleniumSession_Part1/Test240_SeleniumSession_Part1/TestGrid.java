package Test240_SeleniumSession_Part1.Test240_SeleniumSession_Part1;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class TestGrid {
    @Test
    public void mailTest() throws MalformedURLException{
    	
            RemoteWebDriver driver=new RemoteWebDriver(new     URL("http://localhost:4444/wd/hub"), dr);
             driver.navigate().to("http://gmail.com");
             driver.findElement(By.xpath("//input[@id='Email']")) .sendKeys("username");
             driver.findElement(By.xpath("//input[@id='Passwd']")) .sendKeys("password");
             driver.close();
}
}
