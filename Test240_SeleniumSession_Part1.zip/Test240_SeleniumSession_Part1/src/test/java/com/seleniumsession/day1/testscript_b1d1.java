package com.seleniumsession.day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class testscript_b1d1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver wd = new FirefoxDriver();
		
		wd.get("https://www.google.com");
		wd.close();
		
		

	}

}
