package ActionsDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
public class ActionsDemoScript {
	public static void main(String args[]) throws InterruptedException {
		WebDriver wd = new FirefoxDriver();
		//wd.get("https://www.naukri.com/");
		//click on login
		Actions act = new Actions(wd);
		wd.get("https://www.naukri.com/");
		WebElement el = wd.findElement(By.xpath("//*[@title=\"Jobseeker Register\"]"));
		Thread.sleep(1000);
	    el.click();
	    Thread.sleep(2000);
		System.out.println("hello");
		WebElement el2=wd.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div/div[2]/div/button/span[2]"));
		Thread.sleep(20000);
		act.doubleClick(el).perform();
		
	}
}
