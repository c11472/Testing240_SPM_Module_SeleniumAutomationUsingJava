package com.selenium.day3;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CalculateLowestPrice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver wd = new FirefoxDriver();
		wd.get("https://www.amazon.in/");
		
		wd.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]")).sendKeys("C with datastructure");
		wd.findElement(By.xpath("//*[@id=\"nav-search-submit-button\"]")).click();
		String lxp = "/html/body/div[1]/div[1]/div[1]/div[1]/div/span[1]/div[1]/div[";
		String rxp= "]/div/div/span/div/div/div/div[2]/div/div/div[3]"
				+ "/div[1]/div/div[1]/div[2]/div[1]/a/span/span[2]/span[2]";
		String mxp;
		ArrayList <WebElement> lst= new ArrayList(); 
		for(int i=3;i<=10;i++) {
			mxp = lxp+i+rxp;
			lst.add((WebElement) wd.findElement(By.xpath(mxp)));
			//System.out.println(lst.get(i).getText());    		
		}
		System.out.println(lst.size());
	   }

}
