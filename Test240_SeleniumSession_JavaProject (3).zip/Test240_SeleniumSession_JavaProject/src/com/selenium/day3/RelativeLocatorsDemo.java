package com.selenium.day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.locators.RelativeLocator;

public class RelativeLocatorsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        System.setProperty("webdriver.chrome.driver", "path_to_chromedriver");

        // Initialize WebDriver
        WebDriver driver = new ChromeDriver();

        // Open the website
        driver.get("https://awesomeqa.com/ui");

        // Maximize browser window
        driver.manage().window().maximize();

        // Find username and password fields using relative locators
        WebElement el =  (WebElement) RelativeLocator.with(By.tagName("")).above(By.id(""));
        WebElement el1 = driver.findElement(RelativeLocator.with(By.id(""))
                                    .below(By.id("usernameField"))
                                    .toRightOf(By.tagName("")));

        // Enter username and password
        el1.sendKeys("your_username");
        el1.sendKeys("your_password");



	}

}
