package com.seleniumsession.Testing240day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class TestScript002 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		
		EdgeDriver driver = new EdgeDriver();
		driver.get("https://www.awesomeqa.com/ui");
		// FirefoxDriver
		//ChromeDriber
		//EdgeDriver
		
		//WebDriver wd = new WebDriver();=Invalid statement , WebDriver is an interface

	}

}
