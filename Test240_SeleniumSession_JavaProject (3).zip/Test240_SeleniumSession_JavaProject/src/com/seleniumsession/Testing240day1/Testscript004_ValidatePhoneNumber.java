package com.seleniumsession.Testing240day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Testscript004_ValidatePhoneNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver wd = new FirefoxDriver();
		wd.get("https://www.awesomeqa.com/ui");
		
		String exp_phno =  "+91:1212121212";
		
		String act_phoneNum = wd.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[1]/span")).getText();
		System.out.println("Actual phone number : " + act_phoneNum); //12345678
		
		if(exp_phno.endsWith(act_phoneNum)) {
			System.out.println("Correct phone number");
		}
		else {
			System.out.println("Incorrect phone number");
		}
		

	}

}
