package com.seleniumsession.Testing240day1;
/**
 * To check whether the user is able to launch 
 * awesomeqa app in firefox browser
 * 
 * 1. Step validation:
 *      getTitle()
 *      equals method
 */

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Testscript003_ValidatePageTitle {
	public static void main(String args[]) {
	WebDriver fd = new FirefoxDriver();
	
	String expTitle = "Your Store";
	
	// Launch the AUT in firefox browser
	fd.get("https://www.awesomeqa.com/ui");
	String val = fd.getTitle();
	
	//Validate successful launch of AUT
	//By.linkText(val) --- // links in the page
	
	
	if(expTitle.equals(val)) {
	    System.out.println("The application has been "
	    		+ "launched successfully");
	}
	else {
		System.out.println("Invalid url , please check !");
	}
	
}
}