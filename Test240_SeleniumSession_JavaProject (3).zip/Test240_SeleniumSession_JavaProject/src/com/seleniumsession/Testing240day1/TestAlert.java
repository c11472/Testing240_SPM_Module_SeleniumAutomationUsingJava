package com.seleniumsession.Testing240day1;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestAlert {
	public static void main(String args[]) {
		WebDriver wd = new ChromeDriver();
		
		wd.get("https://mail.rediff.com/cgi-bin/login.cgi");	
		wd.findElement(By.name("proceed")).click();
		
		Alert act = wd.switchTo().alert();
		System.out.println(act.getText());
		act.accept();
		
		
	}

}
