package com.seleniumsession.Testing240day1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginTestAutomation_1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver wd;
		wd=new FirefoxDriver();
		
		String usernamevalue = "testdatauser";
		String passwordvalue = "passcode123";
		
		String unmLocate_xpath ="//*[@id=\"input-email\"]";
		String passLocate_xpath = "//*[@id=\"input-password\"]";
		String loginbutton_xpath="//input[@type=\"submit\"]";
		
		
		String unmLocate_csselector ="#input-email";
		String passLocate_csSelector = "#input-password";
		String loginbutton_csSelector="#content > div > div:nth-child(2) > div > form > input";
		
		
		
		
		
		//step1
		wd.get("https://awesomeqa.com/ui/index.php?route=account/login");
		Thread.sleep(2000);
		//step-2
		
		/*wd.findElement(By.xpath(unmLocate_xpath)).sendKeys(usernamevalue);
		Thread.sleep(2000);
		wd.findElement(By.xpath(passLocate_xpath)).sendKeys(passwordvalue);
		wd.findElement(By.xpath(passLocate_xpath)).sendKeys(Keys.ENTER);*/
		
		/*wd.findElement(By.cssSelector(unmLocate_csselector)).sendKeys(usernamevalue);
		wd.findElement(By.cssSelector(passLocate_csSelector)).sendKeys(passwordvalue);
		wd.findElement(By.cssSelector(loginbutton_csSelector)).click();*/
		
		
		
	/*	wd.findElement(By.id("input-email")).sendKeys("testdata123");
		
		wd.findElement(By.id("input-password")).sendKeys("pwserdty");
		
		wd.findElement(By.cssSelector(loginbutton_csSelector)).click();*/
		
		
		
         wd.findElement(By.name("email")).sendKeys("testdata123");
		
		 wd.findElement(By.name("password")).sendKeys("pwserdty");
		
		

		
		//Selenium  By is an abstract class
		/*
		By is abstract class.
		By.xpath(loginbutton_csSelector)
		By.cssSelector(loginbutton_csSelector)
		By.id(loginbutton_csSelector)
		By.name(usernamevalue)
		By.linkText(loginbutton_csSelector)
		By.partialLinkText(loginbutton_csSelector)
		By.tagName(loginbutton_csSelector)
		By.className(loginbutton_csSelector)*/
		
		
	}

}
