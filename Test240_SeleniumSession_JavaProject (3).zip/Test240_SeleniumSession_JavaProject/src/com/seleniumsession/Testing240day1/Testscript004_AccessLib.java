package com.seleniumsession.Testing240day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Testscript004_AccessLib {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver wd = new FirefoxDriver();
		LibraryTestDaya1 testobj = new LibraryTestDaya1();
		
		//call methods
		//step-1
		testobj.init(wd);
		//step2
		testobj.Launch_App_Test();
		//step-3
		testobj.Validate_AppLaunch();

	}

}
