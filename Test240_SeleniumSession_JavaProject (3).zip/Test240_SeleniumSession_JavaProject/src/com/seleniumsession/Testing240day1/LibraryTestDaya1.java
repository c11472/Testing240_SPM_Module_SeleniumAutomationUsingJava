package com.seleniumsession.Testing240day1;

import org.openqa.selenium.WebDriver;

public class LibraryTestDaya1 {
	WebDriver wd;
	String ExpTitle="Your Store";
	String actTitle;
	
	//Driver initialization
	public void init(WebDriver wd) {
		this.wd=wd;
		
		
	}
	
	public void Launch_App_Test() {
		
		wd.get("https://www.awesomeqa.com/ui");
		
	}
	
	public void Validate_AppLaunch() {
		
	    actTitle = wd.getTitle();
		System.out.println(actTitle);  // pageTitle
		if(ExpTitle.equals(actTitle)) {
			System.out.println("App launched successfully"+ " "+ actTitle);
		}
		else {
			System.out.println("Invalid url");
		}
		
	}
	
	
	
	
	
	
	

}
