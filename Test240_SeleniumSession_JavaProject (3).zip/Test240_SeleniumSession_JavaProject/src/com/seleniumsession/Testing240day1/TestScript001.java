package com.seleniumsession.Testing240day1;

import org.openqa.selenium.firefox.FirefoxDriver;

public class TestScript001 {
	public static void main(String args[]) throws InterruptedException {
		FirefoxDriver driver; //This is a class to access firefox browser
		driver=new FirefoxDriver();
		
		//Maximize the browser
		
		driver.manage().window().maximize();
		//driver.get("https://www.google.com"); // instance1
		driver.get("https://www.awesomeqa.com/ui"); // instance2
		
		//driver.quit();
		
		String PageTitlePage1=driver.getTitle();
		System.out.println("The page title of first page is "+ " " + PageTitlePage1);
		
		Thread.sleep(10000); // Thread class method to make the process wait for a stipulated amount of time
		
		//driver.close();
		
		driver.navigate().to("https://awesomeqa.com/ui/index.php?route=account/register");
		Thread.sleep(3000);
		driver.navigate().to("https://awesomeqa.com/ui/index.php?route=account/login");
		driver.manage().deleteAllCookies();// remove all the browser cookies
		
  }
}
