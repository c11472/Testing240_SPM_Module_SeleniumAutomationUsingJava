package co.seleniumsession.Testing240day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class RedBusCallendar {

	public static void main(String[] args) throws InterruptedException {
		WebDriver wd = new ChromeDriver();
		wd.get("https://www.makemytrip.com/");
		
		Thread.sleep(10000);
		
		String val=wd.findElement(By.xpath("(//div/p[contains(text(),\"4\")])[1]\r\n")).getText();
	    
	    System.out.println(val); // 4
	}

}
