package co.seleniumsession.Testing240day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginUsingWebElemet {

	private static final String WebElement = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver wd;
		wd = new FirefoxDriver();
		wd.get("https://awesomeqa.com/ui/index.php?route=account/login");
		String xp1=
        
		WebElement unm = wd.findElement(By.id("input-email"));
		
		WebElement pwd =
				wd.findElement(By.id("input-password"));
		WebElement lgin = wd.findElement(By.xpath("//input[@type=\"submit\"]"));
		unm.clear();
		unm.sendKeys("gayatri@gmail.com");
		pwd.clear();
		pwd.sendKeys("passcode45");
		lgin.click();
		

	}

}
