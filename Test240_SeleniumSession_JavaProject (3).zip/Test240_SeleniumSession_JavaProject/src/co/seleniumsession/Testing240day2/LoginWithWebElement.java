package co.seleniumsession.Testing240day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginWithWebElement {
	public static void main(String args[]) {
		WebDriver wd = new ChromeDriver();
		wd.get("https://demo.guru99.com/test/newtours/register.php");
		String fname1= "firstName";
		WebElement fname = wd.findElement(By.name("firstName"));
		//WebElement lName = wd.findElement(By.name("lastName"));
		
		
		if(fname.isDisplayed()) {
			fname.clear();
			fname.sendKeys("testuser1");
			
		}
		else {
			System.out.println("The element is not present");
			
		}
		// using string
		
	//	wd.findElement(By.name(fname1)).sendKeys("test343");
		
		
	}

}
