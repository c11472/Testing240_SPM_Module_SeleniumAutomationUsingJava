package co.seleniumsession.Testing240day2;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Count_Links_DisplayName_TagName {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver wd;
		wd = new ChromeDriver();
		
		wd.get("https://www.awesomeqa.com/ui");
		
		List <WebElement> list1 =
				wd.findElements(By.tagName("a"));
		
		
		int count = list1.size();
		System.out.println("The number of links in the page:" + count);
		
		//Display all the link names
		
		for(int i=0;i<=count;i++) {
			String LinkNames=list1.get(i).getText();
			Thread.sleep(500);
			System.out.println(LinkNames);
		}
	}
}
