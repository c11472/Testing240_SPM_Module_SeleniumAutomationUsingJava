package co.seleniumsession.Testing240day2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class SelectDemo_ToSelectOption {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		FirefoxDriver wd = new FirefoxDriver();
		
		wd.get("https://demo.guru99.com/test/newtours/register.php");
		
		// Select the country "AURUBA"
		
		//Select sel = wd.findElement(By.xpath("https://demo.guru99.com/test/newtours/register.php"));
		Select sel=
				new Select(wd.findElement(By.xpath("//select[@name=\"country\"]")));
		//Thread.sleep(2000);
		
		//sel.selectByVisibleText("ARUBA");
		
		//sel.selectByIndex(5);
		
		sel.selectByValue("BASSA DE INDIA");
		
		List <WebElement> items = sel.getOptions();
		
		for(int i=0;i<=items.size()-1;i++) {
			System.out.println(items.get(i).getText());
			Thread.sleep(200);
		}
	
	}

}
