package co.seleniumsession.Testing240day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Login_OpencartUsingIdName {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver wd;
		wd = new FirefoxDriver();
		wd.get("https://awesomeqa.com/ui/index.php?route=account/login");
		wd.findElement(By.id("input-email")).clear();
		Thread.sleep(2000);
		wd.findElement(By.id("input-email")).sendKeys("test5@gmail.com");
		Thread.sleep(2000);

		wd.findElement(By.name("password")).clear();
		wd.findElement(By.name("password")).sendKeys("5646567");
		
		;

	}

}
