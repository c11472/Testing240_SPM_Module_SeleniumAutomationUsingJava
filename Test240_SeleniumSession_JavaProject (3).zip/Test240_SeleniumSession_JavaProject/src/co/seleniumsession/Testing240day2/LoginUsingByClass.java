package co.seleniumsession.Testing240day2;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginUsingByClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FirefoxDriver wd = new FirefoxDriver();
		//invoke app
		wd.get("https://www.awesomeqa.com/ui");
		wd.navigate().to("https://awesomeqa.com/ui/index.php?route=account/login");
		
		// POM 
		By unm = By.id("input-email");
		By pwd = By.id("input-password");
		By lgin = By.xpath("//input[@type=\"submit\"]");
		
		
		//login script
		wd.findElement(unm).sendKeys("testdata1");
		
		wd.findElement(pwd).sendKeys("passcode45");
		
		wd.findElement(lgin).click();
		

	}

}
