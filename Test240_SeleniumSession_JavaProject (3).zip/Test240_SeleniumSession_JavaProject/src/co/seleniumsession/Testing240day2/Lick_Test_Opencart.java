package co.seleniumsession.Testing240day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Lick_Test_Opencart {
	public static void main(String args[]) throws InterruptedException {
		WebDriver wd = new FirefoxDriver();
		
		wd.get("https://awesomeqa.com/ui/index.php?route=account/login");
	    String val=wd.findElement(By.linkText("Forgotten Password")).getText();
	    System.out.println(val);
	    Thread.sleep(2000);
		//wd.findElement(By.linkText("Forgotten Password")).click();
		wd.findElement(By.partialLinkText("Forg")).click();
		Thread.sleep(2000);
		System.out.println("done");
		Thread.sleep(2000);
		//wd.close();
		
		
	}

}
